This is my implementation of HW4 for the subject PV079.
This is the assignment:

Write a program that takes 4 files as arguments:
- a public RSA key (in PEM format),
- a message (txt file),
- a signature (binary file - RSA with PKCS #1 v1.5 padding and SHA-256 hash),
- a malicious message (txt file).

If the signature of the message is correct, output "Correct signature".

If the signature is incorrect, attempt to compute the private key as it happens
with the fault attack on RSA-CRT. After obtaining the private key, compute
a signature of a malicious message and save it in a file "malicious_sig.sha256".

It is written in TS and the implementation is in main.ts.

To build you need tsc:
sudo apt install node-typescript

and node:
https://github.com/nodesource/distributions/blob/master/README.md

then you can build:
tsc --build tsconfig.json

run npm:
npm install

and run the program:
node main.js [arg_1 arg_2 ...]
