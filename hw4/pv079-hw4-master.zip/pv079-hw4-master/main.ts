// crypto lib for hash and verify
const crypto = require("crypto");
// filesystem
const fs = require("fs");
// bigint for large numbers manipulation
const bigInt = require("big-integer");
// nodersa for parsing public key
const NodeRSA = require('node-rsa');
// converting bigint <--> buffer
import { toBigIntBE, toBufferBE } from 'bigint-buffer';

// get arguments
const myArgs = process.argv.slice(2);
const pubKeyData : string = fs.readFileSync(myArgs[0], "utf-8");
const messageData : Buffer = fs.readFileSync(myArgs[1]);
const signatureData : Buffer = fs.readFileSync(myArgs[2]);
const malMessageData : Buffer = fs.readFileSync(myArgs[3]);

// verify provided signature from: pubKeyData, message, signature
const verify = crypto.createVerify("sha256");
verify.write(messageData);
verify.end();
const valid : boolean = verify.verify(pubKeyData, signatureData);

if (valid) {
    console.log("Correct signature");
    process.exit(0);
}

function padMessage($messageHash : string) : string {
    // 200 FFs to create 256B (2048b) pad message
    let res : string = "0001ff";
    for (let i = 0; i < 200; i++) {
        res += "ff";
    }
    res += "ff00" + "3031300d060960864801650304020105000420" + $messageHash;
    return res;
}

// compute hash of message, this hash is used in padding
const hash = crypto.createHash("sha256");
hash.update(messageData);
const messageHash : string = hash.digest("hex");

// pad message and create m
const m : typeof bigInt = toBigIntBE(Buffer.from(padMessage(messageHash), "hex"));
// convert signature bytes to bigint
const sPrime : typeof bigInt = bigInt(toBigIntBE(signatureData));

// parse the public key
const rsaKey = new NodeRSA();
rsaKey.importKey(pubKeyData);
const publicComponents = rsaKey.exportKey("components-public");
// get N and e
const N : typeof bigInt = bigInt(toBigIntBE(publicComponents.n));
const e : number = rsaKey.keyPair.e;

// s'^e mod N
const part1 = sPrime.modPow(bigInt(e), N);

// (part1 - m)
const part2 = part1.minus(m);

// (part2 mod N)
const part3 = part2.mod(N);

// GCD(part3, N)
const p = bigInt.gcd(N, part3);

// q = N/p
const q = N.divide(p);

// check that q*p == N
console.assert((q.multiply(p)).compare(N) === 0);

// compute phi(N)
const pMinusOne = p.minus(bigInt.one);
const qMinusOne = q.minus(bigInt.one);
const phiN = pMinusOne.multiply(qMinusOne);
// compute d from e and phi(N)
const d = bigInt(e).modInv(phiN);

// sanity check that d*e = 1 mod phi(N)
const de = d.multiply(e);
const deMod = de.mod(phiN);
console.assert(deMod.compare(bigInt.one) === 0);

// p, q, e, d, N is now known and should be correct, crete hash of malicious message
const hashMal = crypto.createHash("sha256");
hashMal.update(malMessageData);
const malMessageHash : string = hashMal.digest("hex");

// create padded malicious message in hex
const malMessagePadded : string = padMessage(malMessageHash);
// covert to bigint
const mMal = toBigIntBE(Buffer.from(malMessagePadded, "hex"));
// compute malicious signature
const malSignature = bigInt(mMal).modPow(d, N);
// convert computed signature to hex
const a : Buffer = Buffer.from(malSignature.toArray(16).value);
let res : string = "";
for (let i = 0; i < a.length; i += 2) {
    res += a[i].toString(16) + a[i + 1].toString(16);
}
// and write to file
fs.writeFileSync("malicious_sig.sha256", Buffer.from(res, "hex"));
